//
//  ViewController.swift
//  Assign-1-Hello, WY!
//
//  Created by Emily Denham on 1/14/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

